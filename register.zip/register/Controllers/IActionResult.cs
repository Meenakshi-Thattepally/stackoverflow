﻿namespace Register.Controllers
{
    public interface IActionResult<T>
    {
    }
}