﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Register.Models;
using System.Threading.Tasks;

namespace Register.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("AllowOrigin")]
    public class UserController : ControllerBase
    {


        private readonly IConfiguration  _config;
        public readonly UserContext _context;

        public UserController(IConfiguration config ,UserContext context)
        {
            _config = config;
            _context = context;
        }
        [HttpPost("CreateUser")]
        public IActionResult Create(User user )

        {
            _context.Users.Add(user);

            _context.SaveChanges();
           // = user;
            return Ok(user); 
        }
        [HttpGet]

        public async Task<IActionResult> Reconnect()

        {

            var cmtt = await _context.cmntsss.ToListAsync();
            //ctd.MemberSince = System.DateTime.Now;

            ////_context.cmntsss.Add(ctd);
            ////_context.cmntsss.Update(ctd);
            //_context.cmntsss.Attach(ctd).Property(x => x.QuestionID == ctd.QuestionID).IsModified = true;

            //_context.SaveChanges();


            return Ok(cmtt);
        }


    }

}

//https://localhost:44393/weatherforecast