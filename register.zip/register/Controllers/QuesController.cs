﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Register.Models;
using System.Linq;
using System.Threading.Tasks;

namespace Register.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class QuesController : ControllerBase
    {
        private readonly IConfiguration _config;

        public readonly UserContext _context;


        public QuesController(IConfiguration config, UserContext context)
        {
            _config = config;
            _context = context;
        }

        [HttpPost("Question")]

        public IActionResult Recreate(Ques qt)

        {
            qt.MemberSince = System.DateTime.Now;

            _context.questionsss.Add(qt);
            _context.SaveChanges();

            return Ok(qt);
        }



        [HttpPost("popy")]

        public IActionResult Recreate5(Ques qt)



        {


            qt.MemberSince = System.DateTime.Now;
            var currentQuestion = _context.questionsss.Where(x => x.QuestionID == qt.QuestionID).FirstOrDefault();


            if (currentQuestion == null)
            {
               

            }
            else
            {
                currentQuestion.Viewscount += 1;

            }
            //_context.cmntsss.Add(ctd);
            //_context.cmntsss.Update(ctd);
            //_context.cmntsss.Attach(ctd).Property(x => x.CmntID == ctd.CmntID).IsModified = true;



            _context.SaveChanges();




            return Ok(qt);
        }
        //}
        [HttpGet]

        public async Task<IActionResult> Recreate()

        {

            var cmtt = await _context.questionsss.ToListAsync();
            //ctd.MemberSince = System.DateTime.Now;

            ////_context.cmntsss.Add(ctd);
            ////_context.cmntsss.Update(ctd);
            //_context.cmntsss.Attach(ctd).Property(x => x.QuestionID == ctd.QuestionID).IsModified = true;

            //_context.SaveChanges();


            return Ok(cmtt);




        }

        [HttpGet("{id}")]
        public async Task<Ques> Reconnect(int id)
        {
            return await _context.questionsss.Where(i => i.QuestionID == id).FirstAsync();


        }
    }
}
