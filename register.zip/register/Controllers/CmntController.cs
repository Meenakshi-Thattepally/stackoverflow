﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Register.Models;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Register.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CmntController : ControllerBase
    {
        private const EntityState modified = EntityState.Modified;
        private readonly IConfiguration _config;
        public readonly UserContext _context;
      
        public CmntController(IConfiguration config, UserContext context)
        {
            _config = config;
            _context = context;
        }



        [HttpPost("Cmnt")]

        public IActionResult Reconnect(Cmnt ctd)

        {


            ctd.MemberSince = System.DateTime.Now;
            //var currentQuestion = _context.cmntsss.Where(x => x.QuestionID == ctd.QuestionID).FirstOrDefault();
            //currentQuestion.Votescount += 1;

            _context.cmntsss.Add(ctd);
            //_context.cmntsss.Update(ctd);
            //_context.cmntsss.Attach(ctd).Property(x => x.CmntID == ctd.CmntID).IsModified = true;

            _context.SaveChanges();


            return Ok(ctd);
        }


        //[HttpPost]

        //public IActionResult Reconnect9(Cmnt ctd)

        //{


        //    ctd.MemberSince = System.DateTime.Now;
        //    var currentQuestion = _context.cmntsss.Where(x => x.CmntID == ctd.CmntID).FirstOrDefault();
        //    currentQuestion.Votescount += 1; 

        //    //_context.cmntsss.Add(ctd);
        //    //_context.cmntsss.Update(ctd);
        //    //_context.cmntsss.Attach(ctd).Property(x => x.CmntID == ctd.CmntID).IsModified = true;

        //    _context.SaveChanges();


        //    return Ok(ctd);
        //}






        [HttpPost("opo")]

        public IActionResult Reconnect9(Cmnt ctd)



        {
            

            ctd.MemberSince = System.DateTime.Now;
            var currentQuestion = _context.cmntsss.Where(x => x.CmntID == ctd.CmntID).FirstOrDefault();
            if (currentQuestion == null)
            {
            }
            else
            {
                currentQuestion.Votescount += 1;


            }
            //_context.cmntsss.Add(ctd);
            //_context.cmntsss.Update(ctd);
            //_context.cmntsss.Attach(ctd).Property(x => x.CmntID == ctd.CmntID).IsModified = true;



            _context.SaveChanges();




            return Ok(ctd);
        }




        [HttpPost("pop")]

        public IActionResult Reconnect5(Cmnt ctd)



        {


            ctd.MemberSince = System.DateTime.Now;
            var currentQuestion = _context.cmntsss.Where(x => x.QuestionID == ctd.QuestionID).FirstOrDefault();
            if (currentQuestion == null)
            {
            }
            else
            {
                currentQuestion.Viewscount += 1;


            }
            //_context.cmntsss.Add(ctd);
            //_context.cmntsss.Update(ctd);
            //_context.cmntsss.Attach(ctd).Property(x => x.CmntID == ctd.CmntID).IsModified = true;



            _context.SaveChanges();




            return Ok(ctd);
        }
        //[HttpPut("Cmnt")]

        //public IActionResult Reconnect2(Cmnt ctd)

        //{
        //    if (ctd is null)
        //    {
        //        throw new ArgumentNullException(nameof(ctd));
        //    }

        //    var cmtt = _context.cmntsss.ToListAsync();
        //    //ctd.MemberSince = System.DateTime.Now;

        //    //_context.cmntsss.Add(ctd);
        //    _context.cmntsss.Update(ctd);
        //    //_context.cmntsss.Attach(ctd).Property(x => x.QuestionID == ctd).IsModified = true;

        //    _context.SaveChanges();


        //    return Ok(cmtt);
        //}


        [HttpGet]

        public async Task<IActionResult> Reconnecte()

        {

            var cmtt = await _context.cmntsss.ToListAsync();
            


            return Ok(cmtt);


        }


        [HttpGet("{id}")]
        public async Task<Cmnt> Reconnect(int id)
        {
            return await _context.cmntsss.Where(i => i.CmntID == id).FirstAsync();


        }

        //[HttpPut("{id}")]
        //public async Task<IActionResult<Cmnt>>rec(int id, Cmnt cct)
        //{
        //    _context.Entry(cct).State = modified;
        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }


        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!CmntExists(id))
        //        {
        //            return (IActionResult<Cmnt>)NoContent();

        //        }
        //    }
    }

        //private bool CmntExists(int id)
        //{
        //    throw new NotImplementedException();
        //}
    }
