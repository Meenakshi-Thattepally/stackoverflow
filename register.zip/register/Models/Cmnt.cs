﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System;

namespace Register.Models
{
    public class Cmnt
    {
       

        [Key]
        public int CmntID { get; set; }



        public string Comment { get; set; }

        public DateTime MemberSince { get; set; }

        public int? QuestionID { get; set; }
        [ForeignKey(" QuestionID")]
        public User Ques { get; set; }

        public string Username { get; set; }

       public int Votescount { get; set; }

        public int Viewscount { get; set; }

    }
}
