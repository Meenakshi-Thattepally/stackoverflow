﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Register.Models
{
    public class Ques
    {
        [Key]
        public int QuestionID { get; set; }



        public string formquestion { get; set; }

        public DateTime MemberSince { get; set; }
      
        public int? UserId { get; set; }
        [ForeignKey("UserId")]
        public User User { get; set; }
        public int Viewscount { get; set; }





    }
}
