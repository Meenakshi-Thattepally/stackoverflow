﻿using Microsoft.EntityFrameworkCore;

namespace Register.Models
{
    public class UserContext:DbContext
    {
        public UserContext(DbContextOptions options):base(options)
        {

        }
        public DbSet<User> Users { get; set; }
        public DbSet<Ques> questionsss { get; set; }
        public DbSet<Cmnt> cmntsss{ get; set; }


    }
}
