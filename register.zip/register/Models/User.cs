﻿using System.ComponentModel.DataAnnotations;

namespace Register.Models
{
    public class User
    {
        [Key]
        public int UserId { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }

        public string email { get; set; }
        //public string pwd { get; set; }
        //public string confirmpwd { get; set; }
    }
}
