﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Register.Migrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    UserId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    firstname = table.Column<string>(nullable: true),
                    lastname = table.Column<string>(nullable: true),
                    email = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.UserId);
                });

            migrationBuilder.CreateTable(
                name: "cmntsss",
                columns: table => new
                {
                    CmntID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Comment = table.Column<string>(nullable: true),
                    MemberSince = table.Column<DateTime>(nullable: false),
                    QuestionID = table.Column<int>(nullable: true),
                    Username = table.Column<string>(nullable: true),
                    Votescount = table.Column<int>(nullable: false),
                    Viewscount = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cmntsss", x => x.CmntID);
                    table.ForeignKey(
                        name: "FK_cmntsss_Users_QuestionID",
                        column: x => x.QuestionID,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "questionsss",
                columns: table => new
                {
                    QuestionID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    formquestion = table.Column<string>(nullable: true),
                    MemberSince = table.Column<DateTime>(nullable: false),
                    UserId = table.Column<int>(nullable: true),
                    Viewscount = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_questionsss", x => x.QuestionID);
                    table.ForeignKey(
                        name: "FK_questionsss_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_cmntsss_QuestionID",
                table: "cmntsss",
                column: "QuestionID");

            migrationBuilder.CreateIndex(
                name: "IX_questionsss_UserId",
                table: "questionsss",
                column: "UserId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "cmntsss");

            migrationBuilder.DropTable(
                name: "questionsss");

            migrationBuilder.DropTable(
                name: "Users");
        }
    }
}
