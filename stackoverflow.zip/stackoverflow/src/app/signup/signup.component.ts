import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DatasService } from '../datas.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
 
a:any;
  constructor(private ds:DatasService,private router:Router) { }

  ngOnInit(): void {
  }
  regform=new FormGroup({
    firstname:new FormControl("",[Validators.required,Validators.minLength(3),Validators.pattern("[a-zA-Z].*")]),
    lastname:new FormControl("",[Validators.required,Validators.minLength(3),Validators.pattern("[a-zA-Z].*")]),
    email:new FormControl("",[Validators.required,Validators.email]),
    pwd:new FormControl("",[Validators.required,Validators.minLength(3),Validators.maxLength(8)]),
    confirmpwd:new FormControl("")
  });

  registersubmitted(){
    

    console.log(this.regform.value);
    
    this.ds.registerUser([
      this.regform.value.firstname,
      this.regform.value.lastname,
      this.regform.value.email,
       this.regform.value.pwd,
       //this.regform.value.confirmpwd

    ]).subscribe(res=>{
      let objj = JSON.parse(res);
      
      console.log(objj.userId)
    let ls=localStorage.setItem('id',objj.userId);
    let ms=localStorage.setItem('name',objj.firstname);
    let hs=localStorage.setItem('lastn',objj.lastname);
    let ns=localStorage.setItem('email',objj.email);
      this.a=objj;
   
      this.router.navigateByUrl(`questions/${this.a.userId}`).then(()=>{
        window.alert(' registered successfully')
      })
      //this.router.navigate('[page_name]',parameters);
    })
  }
  get Firstname():FormControl{
    return this.regform.get("firstname") as FormControl;
  }
  get Lastname():FormControl{
    return this.regform.get("lastname") as FormControl;
  }
  get email():FormControl{
    return this.regform.get("email") as FormControl;
  }
  get pwd():FormControl{
    return this.regform.get("pwd") as FormControl;
  }
  get cpwd():FormControl{
    return this.regform.get("confirmpwd") as FormControl;
  }
  

}
