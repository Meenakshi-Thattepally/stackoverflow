export interface buff{
    id:number,
    cmpny:string,
    img:string,
    seats:number
}