import { Component, Input, OnInit } from '@angular/core';
import { DatasService } from '../datas.service';
import { buff } from './company.model';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent implements OnInit {
searchText:string=''
  // @Input() cmpny:buff={id:0,cmpny:"",img:"",seats:0};
companyData:any;
  constructor(private ds:DatasService) { }


  ngOnInit(): void {
    this.ds.getproddata().subscribe(data=>{console.log(data)
    this.companyData=data},
  err=>{console.log(err)}
      
    )

  }
  

}
