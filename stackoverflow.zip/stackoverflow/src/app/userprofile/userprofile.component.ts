import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css']
})
export class UserprofileComponent implements OnInit {
  name:any;
  id:any;
  lastn:any;
  email:any;

// userId: 112, firstname: 'padma', lastname: 'kundarapu', email: 'meenakshimeenu7286@gmail.com'}email: "meenakshimeenu7286@gmail.com"firstname: "padma"lastname: "kundarapu"userId: 112[[Prototype]]: Object

  constructor() { }

  ngOnInit(): void {
    this.name=localStorage.getItem('name');
    this.id=localStorage.getItem('id');
    this.lastn=localStorage.getItem('lastn');
    this.email=localStorage.getItem('email');
    
  }
  onquest(){

  }

}
