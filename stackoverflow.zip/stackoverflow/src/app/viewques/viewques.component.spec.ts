import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewquesComponent } from './viewques.component';

describe('ViewquesComponent', () => {
  let component: ViewquesComponent;
  let fixture: ComponentFixture<ViewquesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewquesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewquesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
