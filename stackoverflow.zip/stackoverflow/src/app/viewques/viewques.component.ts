import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DatasService } from '../datas.service';

@Component({
  selector: 'app-viewques',
  templateUrl: './viewques.component.html',
  styleUrls: ['./viewques.component.css']
})
export class ViewquesComponent implements OnInit {


  qid:any;
  qname:any;
  time:any;
  uiddd:any;
  manyusers: any;
  ids:any;
  array:any;
  searchquest:string=''
  Viewscount:Number=0;
 
  cni:any;

  constructor(private router:Router,private ds:DatasService) { }

  ngOnInit(): void {



    this.ds.refreshlist2().subscribe((res)=>
    {
      this.array=res;
      
      console.log(this.array)
   
    },err=>{console.log(err)})
    this.qid=localStorage.getItem('qid');
    this.qname=localStorage.getItem('qname');
    this.time=localStorage.getItem('time');
    this.uiddd=localStorage.getItem('uiddd');



    let ud={formquestion:this.qname,
     qid:this.qid,

    }


 this.adduser(ud);
    
  }

  adduser(ud:any){
    
   
    if(localStorage.getItem('QUESTT')!=null){
     this.manyusers=JSON.parse(localStorage.getItem('QUESTT') || '{}')
     this.manyusers=[ud,...this.manyusers]
     }
     else{
      this.manyusers=[ud]
       
     }

     localStorage.setItem('QUESTT',JSON.stringify(this.manyusers))
   let   x=(localStorage.getItem('QUESTT'))

   console.log(this.manyusers,"parvathiiiii");
  
  

    }

 
    cmnt(qid:any,fq:any,userId:Number){
      this.cni ={
        "qqid":qid,
         "question":fq,
        "uid":userId,
        "vcount":this.Viewscount
    
      }
      console.log(this.cni,"ml")
      this.ds.postymethhod(this.cni).subscribe(res=>{
        console.log(res,"dhe views")
    
     })
    //  location.reload()
    
    


  
  
      const ids = this.manyusers.map((obj: { qid: any; }) => obj.qid);
    console.log(ids,"whjikl");


     this.router.navigate(['/cmnts', qid,fq]);
    }

}