import { HttpClient } from '@angular/common/http';
import { Injectable, NgModuleRef } from '@angular/core';
import { Observable } from 'rxjs';
import { buff } from './company/company.model';

@Injectable({
  providedIn: 'root'
})
export class DatasService {
  list: Object | undefined;


  constructor(private http:HttpClient) { }
  baseurl="https://localhost:44393/api";

  

  registerUser(user:Array<any>){
     return this.http.post(this.baseurl+"/User/CreateUser",{firstname:user[0],
      lastname:user[1],
      email:user[2],
      pwd:user[3],
      //confirmpwd:user[4]

     
  },{responseType:'text',});
}
questionQues(qt:any){

  console.log(JSON.parse(qt.id),"shivaaa")

  
  return this.http.post(this.baseurl+"/Ques/Question",{ formquestion:qt.quesform,UserId:(JSON.parse(qt.id))},{responseType:'text',});
}

gettingques(){
  return this.http.get(this.baseurl+"/Ques")

}



commentCmnt(ctd:any){
  console.log((ctd.qid),(ctd.cmntt),(ctd.unid),"op")
  
  // return this.http.post(this.baseurl+"/Cmnt/Cmnt",{ Comment:ctd.cmntt,QuestionID:ctd.qid},{responseType:'text'});
  return this.http.post(this.baseurl+"/Cmnt/Cmnt",{ Comment:ctd.cmntt,QuestionID:JSON.parse(ctd.qid),Username:(ctd.unid)},{responseType:'text'})
}

refreshlist(){
 return this.http.get(this.baseurl+"/Cmnt")
}

 posttmethhod(nid:any){
  console.log(nid.cid,nid.comment,nid.qnid,"jklophgyu")
 
  return this.http.post(this.baseurl+"/Cmnt/opo",{ CmntID :nid.cid,Comment:nid.comment,QuestionID:nid.qnid,Username:nid.uname,Votescount:nid.votescount},{responseType:'text'} )
  
}

postymethhod(ncd:any){
  console.log(ncd.qqid,ncd.question,ncd.uid,JSON.parse(ncd.vcount),"vvies")
 
  return this.http.post(this.baseurl+"/Ques/popy",{QuestionID :ncd.qqid,formquestion:ncd.question,UserId:ncd.uid,  Viewscount:ncd.vcount },{responseType:'text'} )
  
}


refreshlist1(){
  return this.http.get(this.baseurl+"/Cmnt")
 }

 refreshlist2(){
  return this.http.get(this.baseurl+"/Ques")
 }

getproddata():Observable<buff[]>{
  return  this.http.get<buff[]>("https://6328cb014c626ff832b7231c.mockapi.io/company");
 }


}

// mongo db connection error 500
// select top 10 * from question where questionname like '%not found error%'