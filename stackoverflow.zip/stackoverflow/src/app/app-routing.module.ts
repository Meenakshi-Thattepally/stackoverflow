import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AskquestionComponent } from './askquestion/askquestion.component';
import { CmntsComponent } from './cmnts/cmnts.component';
import { CompanyComponent } from './company/company.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { QuestionsComponent } from './questions/questions.component';
import { SignupComponent } from './signup/signup.component';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { ViewquesComponent } from './viewques/viewques.component';


const routes: Routes = [
  {path:'home',component:HomeComponent},

  {path:'login',component:LoginComponent},
  {path:'',component:SignupComponent},

  {path:'questions/:id',component:QuestionsComponent,children:[
    {path:'userprofile',component:UserprofileComponent},
    {path:'askquest',component:AskquestionComponent},
    {path:'company',component:CompanyComponent },
    {path:'viewquest',component:ViewquesComponent},
  


  ]},
  // {path:'viewquest',component:ViewquesComponent}, 
  // // {path:'company',component:CompanyComponent },
   {path:'userprofile',component:UserprofileComponent},
  {path:'cmnts/:qid/:fq',component:CmntsComponent},
 
 

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
