import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CmntsComponent } from './cmnts.component';

describe('CmntsComponent', () => {
  let component: CmntsComponent;
  let fixture: ComponentFixture<CmntsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CmntsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CmntsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
