import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { DatasService } from '../datas.service';

@Component({
  selector: 'app-cmnts',
  templateUrl: './cmnts.component.html',
  styleUrls: ['./cmnts.component.css']
})
export class CmntsComponent implements OnInit {
  id: any;
  fq:any;
  cmntform: FormGroup<{ ctform: FormControl<any>; }>;
  qid: any;
 totalcount=0;
  time:any;
  commentedby:any;
  manyusers: any;
  cnt: any;
  quesno: any;
   newArray:Array<any>=[]
  array:any;
  varray:any;
  narray:any;
  mmmanyusers: any;
  x:any;
  cid: any;
  cnn: any;

  constructor(private router:Router,private route:ActivatedRoute,private ds:DatasService) { 
    this.cmntform = new FormGroup({
      ctform: new FormControl('',[Validators.required])
  });
  }
  cmtdata:any;
  cmtn :any ={
  };
  ngOnInit(): void {
    this.ds.refreshlist1();
    this.ds.refreshlist1().subscribe((res)=>
    {
      this.array=res;
      console.log(res,"plpppp")
      console.log(this.array,"arrr")
      console.log(this.id,"mkoplhu")
      
      for(let i=0;i<this.array.length;i++){
          if(this.array[i].questionID==this.id){
            console.log(this.array[i]);
           this. newArray.push(this.array[i])
         }
          console.log(this. newArray,"rrreee")}
   
    })

    // this.ds.refreshlist1().subscribe((res)=>{
    //   this.array=res;
   


    //   console.log(res,"t")
    // })
    
     console.log(this.ds.refreshlist().subscribe((res)=>{console.log(res,)}),"g")

    this.id=this.route.snapshot.params['qid'];
    this.fq=this.route.snapshot.params['fq'];
    this.qid=localStorage.getItem('qid');
    this.cmtdata=localStorage.getItem('cnt')
    this.cmtdata=JSON.parse(this.cmtdata)
    
  
  
  }
// popcmntid(cid:Number){
//   console.log(cid,"ll[p")
//   this.ds.commentCmnt(this.cid).subscribe(res=>{
//     console.log(res,"devudaaa")

// })
// }
  


  cmntsub(){
    console.log(this.cmntform.value.ctform,"paaddu");
    // console.log(this.id,"uoppp")
  console.log(localStorage.getItem('qid'),"odf")
    this.cmtn ={
      "qid":this.id,
       "unid":localStorage.getItem('name'),
      "cmntt":this.cmntform.value.ctform,

    }
    console.log(this.cmtn,"dog")
    
    this.ds.commentCmnt(this.cmtn,).subscribe(res=>{
     
      let objj = JSON.parse(res)
      console.log(objj,"vnnt");
      console.log(objj.comment,"nni");
      console.log(objj.username,"nenu");
      console.log(objj.questionID,"marii");


 if(this.cmntform.valid){
//        let ms=localStorage.setItem('comment',(objj.comment));
//      let hs=localStorage.setItem('time',objj. memberSince);
//       let ns=localStorage.setItem('usern',objj.username);
//       let ks=localStorage.setItem('forquestion',objj.questionID);
//       let comment=localStorage.getItem('comment');
    
//       let ttt=localStorage.getItem('time');
//        let commentedby=localStorage.getItem('usern');

//        let questionby=localStorage.getItem('forquestion');

//        console.log(comment,ttt,commentedby,questionby,"ccc")

       
//    let ud={comment:comment,
//        unnid:commentedby,
//      timee:ttt,
//      quesno:questionby,
 
//      }

//      console.log(ud,"thisss.ud")
//  this.adduser(ud);
 
 
//   adduser(ud){
    
   
//   if(localStorage.getItem('cnt')!=null){
//    this.manyusers=JSON.parse(localStorage.getItem('cnt') || '{}')
//    this.manyusers=[ud,...this.manyusers]
//    }
//    else{
//     this.manyusers=[ud]
     
//    }

//    localStorage.setItem('cnt',JSON.stringify(this.manyusers))
//  let   x=(localStorage.getItem('cnt'))

//  console.log(this.manyusers,"mmmanyusers");



// //   }

  }});
// console.log(this.manyusers,"checkk")
    

   
  }
  adduser(ud: { comment: string | null; unnid: string | null; timee: string | null;  quesno: string | null }) {

    {
      if(localStorage.getItem('cnt')!=null){
       this.manyusers=JSON.parse(localStorage.getItem('cnt') || '{}')
       this.manyusers=[ud,...this.manyusers]
       }
       else{
        this.manyusers=[ud]
         
       }
    
       localStorage.setItem('cnt',JSON.stringify(this.manyusers))
       this.x=(localStorage.getItem('cnt'))
       console.log(this.x);
     console.log(this.manyusers[0].quesno,"mmmanyusers");
     for(let i=0;i<this.manyusers.length;i++){
      if(this.manyusers[i].quesno==this.id){
        console.log(this.manyusers[i]);
        // this.newArray.push(this.manyusers[i])
      }
     }
    //  console.log( this.newArray,"r")
    
    console.log(this.id,"present ques no")
  
    //   }

    console.log(this.id,"present ques no")

  }
  

  console.log(this.manyusers,"uuu")



 
}

popcmntid(cid:Number,comment:string,qnid:Number,username:string,votescount:Number){
  // console.log(cid,comment,qnid,"ll[p")
  this.cnn ={
    "cid":cid,
     "comment":comment,
    "qnid":qnid,
    "uname":username,
    "votescount":votescount

  }

  
  this.ds.posttmethhod(this.cnn).subscribe(res=>{
    console.log(res,"dhe votes")

 })
 location.reload()
}

}

