import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import{ReactiveFormsModule,FormsModule} from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import{HttpClientModule} from '@angular/common/http';
import { DatasService } from './datas.service';
import { QuestionsComponent } from './questions/questions.component';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { ViewquesComponent } from './viewques/viewques.component';
import { CmntsComponent } from './cmnts/cmnts.component';
import {MatChipsModule} from '@angular/material/chips';
import { CompanyComponent } from './company/company.component';
import {MatCardModule} from '@angular/material/card';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatIconModule} from '@angular/material/icon';
import {MatToolbarModule} from '@angular/material/toolbar';

import {MatFormFieldModule} from '@angular/material/form-field';
import { AskquestionComponent } from './askquestion/askquestion.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LogoutComponent } from './logout/logout.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    SignupComponent,
    QuestionsComponent,
    UserprofileComponent,
    ViewquesComponent,
    CmntsComponent,
    CompanyComponent,
    AskquestionComponent,
    LogoutComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatChipsModule,
    MatCardModule,
    MatFormFieldModule,
    FormsModule,
    MatIconModule,
    MatSidenavModule,
    Ng2SearchPipeModule,
    MatToolbarModule,
    BrowserAnimationsModule
  ],
  providers: [DatasService],
  bootstrap: [AppComponent]
})
export class AppModule { }
