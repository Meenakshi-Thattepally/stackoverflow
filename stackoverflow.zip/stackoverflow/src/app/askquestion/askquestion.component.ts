import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { DatasService } from '../datas.service';

@Component({
  selector: 'app-askquestion',
  templateUrl: './askquestion.component.html',
  styleUrls: ['./askquestion.component.css']
})
export class AskquestionComponent implements OnInit {

  name:any;
  id:any;
  lastn:any;
  email:any;
  quesform: any;
  manyusers: any;
  ns:any;
 

  constructor(private ds:DatasService,private router:Router) {
    this.quesform = new FormGroup({
      formquestion: new FormControl()
  });
   }


  qtn :any ={
  };
  ngOnInit(): void {
    this.name=localStorage.getItem('name');
    this.id=localStorage.getItem('id');
    this.lastn=localStorage.getItem('lastn');
    this.email=localStorage.getItem('email');
   
  }


  questionsub(){
    console.log(this.quesform.value.formquestion);
 
    this.qtn ={
      "id":localStorage.getItem('id'),
      "name":localStorage.getItem('name'),
      "quesform": this.quesform.value.formquestion
    }
   
    this.ds.questionQues(this.qtn).subscribe(res=>{
      let objj = JSON.parse(res)
      console.log(objj);
 
      let ls=localStorage.setItem('qid',objj.questionID);
      let ms=localStorage.setItem('qname',objj.formquestion);
      let hs=localStorage.setItem('time',objj. memberSince);
      this.ns=localStorage.setItem('uiddd',objj.userId);
    });
    
    let ud={formquestion:this.quesform.value.formquestion,
     }

 
  // this.adduser(ud);
     
    }

    // adduser(ud:any){
    
   
    //     if(localStorage.getItem('QUESTT')!=null){
    //      this.manyusers=JSON.parse(localStorage.getItem('QUESTT') || '{}')
    //      this.manyusers=[ud,...this.manyusers]
    //      }
    //      else{
    //       this.manyusers=[ud]
           
    //      }
  
    //      localStorage.setItem('QUESTT',JSON.stringify(this.manyusers))
    //    let   x=(localStorage.getItem('QUESTT'))
    
    //    console.log(this.manyusers,"sssss");

  
    onquest(){
      this.router.navigateByUrl('questions/'+this.ns+'/viewques')

    }
    oncamp(){
      this.router.navigateByUrl('questions/'+this.ns+'/company')

    }

}
